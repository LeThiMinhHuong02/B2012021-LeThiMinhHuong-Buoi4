<?php
if (session_id() == '') session_start();
//print_r($_SESSION);
if (isset($_SESSION['id']) == false) {
  header("location:Login.php");
  exit();
}
$email = $_SESSION['email'];
//print_r($_POST);
$loi = "";
if (isset($_POST['btndoimatkhau']) == true) {
  $matkhaucu = md5($_POST['matkhaucu']);
  $matkhaumoi_1 = $_POST['matkhaumoi_1'];
  $matkhaumoi_2 = $_POST['matkhaumoi_2'];

  $conn = new PDO("mysql:host=localhost;dbname=qlbanhang;charset=utf8", "root", "");
  $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
  $sql = "SELECT * FROM customers WHERE email = ?  AND password = ? ";
  $stmt = $conn->prepare($sql);
  $stmt->execute([$email, $matkhaucu]);

  if ($stmt->rowCount() == 0) {
    $loi .= "mat khau cu sai <br>";
  }

  if (strlen($matkhaumoi_1) < 6) {
    $loi .= "mat khau moi ngan <br>";
  }

  if ($matkhaumoi_1 != $matkhaumoi_2) {
    $loi .= "mat khau phai giong nhau <br>";
  }

  if ($loi == "") {
    $sql = "UPDATE customers SET password = ? WHERE email = ?";
    $stmt = $conn->prepare($sql);
    $stmt->execute([md5($matkhaumoi_1), $email]);
    // echo "Da cap nhat";
    header("location:Homepage.php");
    exit();
  }
}
?>

<div class="col-md-9 m-auto">
  <div class="card">
    <div class="card-header bg-primary">ĐỔI MẬT KHẨU</div>
    <div class="card-body">
      <form class="form-horizontal" method="POST">
        <?php if ($loi != "") { ?>
          <div class="alert alert-secondary"><?php echo $loi ?> </div>
        <?php } ?>

        <p> <label for="fullname">Fullname</label>
          <input value="<?php echo $email ?>" type="email" class="form-control" name="email" id="email">
        </p>

        <p> <label for="matkhaucu">Mật khẩu cũ</label>
          <input value="<?php if (isset($matkhaucu) == true) echo $matkhaucu; ?>" type="password" class="form-control" name="matkhaucu" id="matkhaucu">
        </p>
        <p> <label for="matkhaumoi_1">Mật khẩu mới:</label>
          <input value="<?php if (isset($matkhaumoi_1) == true) echo $matkhaumoi_1; ?>" type="password" class="form-control" name="matkhaumoi_1" id="matkhaumoi_1">
        </p>
        <p><label for="matkhaumoi_2">Gõ lại mật khẩu mới:</label>
          <input value="<?php if (isset($matkhaumoi_2) == true) echo $matkhaumoi_2; ?>" type="password" class="form-control" name="matkhaumoi_2" id="matkhaumoi_2">
        </p>
        <p><button type="submit" name="btndoimatkhau" value="doimk" class="btn btn-warning">Đổi mật khẩu</button></p>
      </form>
    </div>
  </div>
</div>